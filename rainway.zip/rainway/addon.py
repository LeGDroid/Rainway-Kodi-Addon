﻿import os
child=os.system('start chrome "https://play.rainway.com/" --start-fullscreen')

