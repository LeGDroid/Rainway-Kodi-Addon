﻿import subprocess
import xbmc

child = subprocess.call(["C:\Rainway\Rainway.bat", "-k"])
